package com.team.teamupadmin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
